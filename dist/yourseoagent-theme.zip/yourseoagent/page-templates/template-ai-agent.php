<?php
/**
 * Template Name: AI SEO-агент
 * Template Post Type: page
 *
 * @package YourSEOAgent
 */

get_header();
?>

<div class="wrap">
  <section class="hero">
    <div class="tag" style="margin-bottom:6px;"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">← Все услуги</a></div>
    <div class="tag">Отчет, на который у команды уходил день — теперь занимает 30 минут</div>
    <div class="hero-word display">AI<span>/</span>AGENT</div>
    <div class="hero-sub">
      <p>Агент подключается к тем системам, которыми вы уже пользуетесь — GSC, Метрика, Вебмастер, Topvisor, Keys.so, Ahrefs, Arsenkin — и отвечает на вопросы о вашем SEO на естественном языке. Не шаблон «для всех», а конфигурация под конкретный стек и приоритетные задачи вашей команды.</p>
      <div class="hero-actions">
        <a class="btn" href="#capabilities">Что умеет</a>
        <a class="btn-outline" href="<?php echo esc_url( YSA_TELEGRAM_URL ); ?>" target="_blank" rel="noopener">Обсудить внедрение</a>
      </div>
    </div>
  </section>

  <div class="stats">
    <div class="stat"><div class="num">День → 30 мин</div><div class="lbl">время подготовки отчета в моей команде</div></div>
    <div class="stat"><div class="num">×4–5</div><div class="lbl">быстрее сбор семантического ядра</div></div>
    <div class="stat"><div class="num">7</div><div class="lbl">систем сводятся в один интерфейс</div></div>
  </div>

  <section>
    <div class="sec-head"><h2>Собирается под вас, а не по шаблону</h2></div>
    <div class="under-grid">
      <div class="under-card">
        <div class="k">СТЕК</div>
        <h4>Подключаем то, чем вы реально пользуетесь</h4>
        <p>У вас может не быть Keys.so или Arsenkin — тогда агент работает на том, что есть: GSC + Метрика + Topvisor, например. Конфигурация собирается под ваш реальный набор инструментов, а не навязывает полный список.</p>
      </div>
      <div class="under-card">
        <div class="k">ЗАДАЧИ</div>
        <h4>Приоритет — по вашей боли, а не по каталогу функций</h4>
        <p>Если сейчас главная проблема — падение трафика, первым внедряется сценарий диагностики. Если команда тонет в отчетах — сначала автоматическая отчетность. Остальное достраивается по мере необходимости.</p>
      </div>
      <div class="under-card">
        <div class="k">МАСШТАБ</div>
        <h4>Рассчитан на большие и сложные сайты</h4>
        <p>Десятки категорий, несколько языковых версий, тысячи страниц — там, где вручную свести данные физически нереально, агент справляется за минуты. Можно ставить задачи вроде «сравни падение трафика по всем языковым версиям одновременно» или «найди каннибализацию между категориями на всех гео» — то, что руками просто не вытащить.</p>
      </div>
    </div>
  </section>

  <section id="capabilities">
    <div class="sec-head"><h2>Что агент уже умеет</h2></div>
    <p class="sec-lead">Не план на будущее — то, что уже экономит SEO-командам часы каждую неделю.</p>
    <div class="cap-list">
      <div class="cap-row">
        <div class="n">01</div>
        <div>
          <h4>Мониторинг SEO-показателей</h4>
          <p>«Проанализируй сайт за последние 30 дней» — агент собирает GSC, Метрику, Topvisor, Вебмастер, сравнивает периоды и объясняет, что произошло с трафиком и позициями.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">02</div>
        <div>
          <h4>Анализ роста и падения</h4>
          <p>Находит запросы и страницы с максимальными потерями или ростом, выпадения из ТОП-3/10/30, падение CTR — сопоставляя сразу несколько источников данных.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">03</div>
        <div>
          <h4>Анализ позиций</h4>
          <p>Через Topvisor — текущие позиции, история, распределение по ТОПам, средняя позиция и видимость, запуск нового съема позиций.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">04</div>
        <div>
          <h4>Работа с семантикой</h4>
          <p>Через GSC, Topvisor, Keys.so и Arsenkin — фактические запросы сайта, отслеживаемая семантика, семантика конкурентов, потерянные ключи.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">05</div>
        <div>
          <h4>Конкурентный анализ</h4>
          <p>«Найди SEO-конкурентов и покажи, где они сильнее» — Keys.so, Ahrefs и Topvisor вместе: семантика → страницы → позиции → трафик → ссылки.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">06</div>
        <div>
          <h4>Анализ контентных возможностей</h4>
          <p>Находит запросы, по которым конкуренты ранжируются, а вы — нет; перспективные страницы; потерянную семантику и точки роста.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">07</div>
        <div>
          <h4>Анализ ссылочного профиля</h4>
          <p>Ahrefs + Keys.so — DR, backlinks, referring domains, анкоры, лучшие страницы по ссылкам, битые backlinks, профили конкурентов.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">08</div>
        <div>
          <h4>Технический SEO и индексация</h4>
          <p>Через Яндекс.Вебмастер — диагностика, Sitemap, индексирование, динамика страниц в поиске, битые внутренние ссылки, отправка URL на переобход.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">09</div>
        <div>
          <h4>SERP-анализ</h4>
          <p>Через Arsenkin и другие источники — получение поисковой выдачи для анализа конкурентов и результатов поиска.</p>
        </div>
      </div>
      <div class="cap-row">
        <div class="n">10</div>
        <div>
          <h4>Автоматическая отчетность</h4>
          <p>Собирает данные из нескольких SEO-систем → анализирует → формирует Google Sheet с исходными данными и Google Doc с выводами → сохраняет в Google Drive.</p>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="sec-head"><h2>Как это выглядит на реальном вопросе</h2></div>
    <p class="sec-lead">Комплексные сценарии — там, где вручную пришлось бы открывать семь вкладок и сводить все самому.</p>

    <div class="scenario">
      <div class="q-title mono">«На какой языковой версии трафик падает сильнее всего — и почему именно там?»</div>
      <div class="flow">
        <span class="fstep">GSC — сравнение по языковым версиям</span><span class="farrow">→</span>
        <span class="fstep">Метрика — подтверждение по гео</span><span class="farrow">→</span>
        <span class="fstep">Topvisor — расхождение позиций между версиями</span><span class="farrow">→</span>
        <span class="fstep">Вебмастер — индексация hreflang</span><span class="farrow">→</span>
        <span class="fstep">Keys.so — локальная семантика</span><span class="farrow">→</span>
        <span class="fstep">ИИ — какая версия и почему</span><span class="farrow">→</span>
        <span class="fstep">Google Docs — отчет по версии</span>
      </div>
    </div>

    <div class="scenario">
      <div class="q-title mono">«Есть ли каннибализация между категориями каталога на разных гео одновременно?»</div>
      <div class="flow">
        <span class="fstep">GSC — пересечения запросов между категориями</span><span class="farrow">→</span>
        <span class="fstep">Topvisor — позиции конфликтующих страниц по гео</span><span class="farrow">→</span>
        <span class="fstep">Keys.so — семантика по каждому гео</span><span class="farrow">→</span>
        <span class="fstep">Ahrefs — куда утекает ссылочный вес</span><span class="farrow">→</span>
        <span class="fstep">Карта конфликтов по категориям</span><span class="farrow">→</span>
        <span class="fstep">План консолидации/перелинковки</span>
      </div>
    </div>
  </section>

  <section>
    <div class="sec-head"><h2>Отдельно — для Betting / iGaming</h2></div>
    <p class="sec-lead">Агент универсален, но именно в этой нише закрывает задачи, с которыми обычный SEO-инструментарий физически не справляется. <a href="<?php echo esc_url( ysa_service_url( 'betting-gaming' ) ); ?>">Подробнее об SEO для Betting/Gaming →</a></p>
    <div class="niche-box">
      <div class="niche-row">
        <div><span class="problem-k">ЗЕРКАЛА И ДУБЛИ</span><span class="problem">Массовый запуск зеркал — это риск угодить под фильтр за дублированный контент между ними</span></div>
        <p class="solution">Агент постоянно сверяет технические сигналы (canonical, hreflang, индексацию) между всеми зеркалами и первым замечает, если поисковик начинает считать их дублями — до того, как под фильтр попадет весь пул доменов.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">SEO, ПРИВЯЗАННОЕ К ДЕНЬГАМ</span><span class="problem">Рост трафика в беттинге ничего не значит без роста конверсии в депозит/регистрацию по каждому гео</span></div>
        <p class="solution">Агент сводит SEO-метрики с бизнес-показателями по каждой локали в одной системе — видно не просто «трафик вырос», а вырос ли он именно там, где конвертится в деньги.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">PBN КАК АКТИВ</span><span class="problem">Whitehat не дает ссылок букмекерам — вся сила в PBN, и ее потеря не видна, пока не рухнули позиции</span></div>
        <p class="solution">Агент постоянно следит за здоровьем донорской сети: какие домены теряют вес или выпадают из индекса — сигнал за недели до того, как это ударит по трафику.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">TIER-1 ГЕО ОДНОВРЕМЕННО</span><span class="problem">Просадка в одном регионе легко прячется за ростом в другом, если смотреть только на общие цифры</span></div>
        <p class="solution">Агент раскладывает динамику по каждому Tier-1 гео отдельно — падение в Африке не спрячется за ростом в США только потому, что общий трафик выглядит стабильным.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">МАССОВЫЙ КАТАЛОГ ЛИНИЙ</span><span class="problem">Тысячи страниц событий — просмотреть вручную, какие теряют трафик, физически невозможно</span></div>
        <p class="solution">Агент сам находит страницы с максимальными потерями и приоритизирует, что чинить в первую очередь — не по алфавиту, а по реальному риску для трафика.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">YMYL И ДОВЕРИЕ</span><span class="problem">Одна просевшая по E-E-A-T карточка букмекера способна утянуть вниз доверие ко всему разделу</span></div>
        <p class="solution">Агент находит именно те review/rating-страницы, которым не хватает сигналов доверия — прежде чем это скажется на всем разделе в глазах Google.</p>
      </div>
      <div class="niche-row">
        <div><span class="problem-k">КАННИБАЛИЗАЦИЯ ГЕО-КАТАЛОГА</span><span class="problem">Одни и те же линии почти дублируются между странами</span></div>
        <p class="solution">Агент находит страницы, конкурирующие друг с другом в разных гео за одну и ту же семантику, и отдает план консолидации или перелинковки вместо взаимного каннибализма в выдаче.</p>
      </div>
    </div>
  </section>

  <section>
    <div class="sec-head"><h2>Как проходит внедрение</h2></div>
    <div class="steps">
      <div class="step"><div class="step-num">01</div><h4>Аудит стека</h4><p>Какими системами вы уже пользуетесь и что доступно по API</p></div>
      <div class="step"><div class="step-num">02</div><h4>Приоритизация</h4><p>Какая задача болит сильнее всего — с нее и начинаем</p></div>
      <div class="step"><div class="step-num">03</div><h4>Настройка</h4><p>Коннекторы и workflow-сценарии под ваш конкретный случай</p></div>
      <div class="step"><div class="step-num">04</div><h4>Обучение</h4><p>Команда формулирует вопросы на естественном языке сама</p></div>
    </div>
  </section>

  <section>
    <div class="sec-head"><h2>Что стоит знать до начала работы</h2></div>
    <p class="sec-lead">Это не маркетинговый FAQ — это условия, на которых я работаю с чужими системами и данными.</p>

    <details class="faq">
      <summary><span class="faq-q">Какой уровень доступа вам нужен — можно ли ограничить его read-only?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">В большинстве сценариев агенту достаточно read-only API-ключей к GSC, Метрике, Ahrefs и т.д. Права на действие (например, отправка URL на переобход) нужны только там, где это явно требуется сценарием, и обсуждаются отдельно по каждой системе — не пакетно на весь стек.</p>
    </details>

    <details class="faq">
      <summary><span class="faq-q">Как вы страхуетесь от того, что агент выдаст неверный вывод по реальным данным?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">Агент не придумывает цифры — все числа идут напрямую из ответов подключенных API. ИИ используется для сопоставления причин и формулировки текста отчета, а не для генерации данных. Каждый отчет ссылается на исходную выгрузку в Google Sheet, так что любую цифру можно проверить вручную.</p>
    </details>

    <details class="faq">
      <summary><span class="faq-q">Если вы станете недоступны — команда сможет сама поддерживать агента, или мы окажемся зависимы от вас?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">При внедрении передаю не только рабочего агента, но и документацию по конфигурации: какие коннекторы подключены, какие сценарии настроены, как добавить новый. Это не черный ящик — команда технически может поддерживать и дорабатывать его без меня.</p>
    </details>

    <details class="faq">
      <summary><span class="faq-q">У нас нет ни одной из перечисленных систем, только внутренняя BI-платформа — ее можно подключить?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">Список из семи систем — это то, что уже проверено в работе, а не жесткое требование. Агент строится на MCP-стеке, который умеет подключаться к любому источнику с API или экспортом данных. Возможность подключения вашей платформы разбираем на этапе аудита стека.</p>
    </details>

    <details class="faq">
      <summary><span class="faq-q">Что произойдет, когда Google или Яндекс поменяют структуру API — агент просто сломается?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">Изменения внешних API — риск для любого инструмента, построенного поверх них, не только для агента. Именно поэтому передается документация по конфигурации: поломка конкретного коннектора — это точечное исправление, а не пересборка всей системы с нуля.</p>
    </details>

    <details class="faq">
      <summary><span class="faq-q">Через полгода добавим новый рынок или систему — это новый проект или входит в сопровождение?</span><span class="faq-chev"></span></summary>
      <p class="faq-a">Расширение уже настроенных сценариев на новый рынок или языковую версию — обычно донастройка существующей конфигурации, а не проект с нуля. Подключение совсем новой системы (нового API) — отдельный коннектор, оценивается по факту, но дешевле и быстрее первичного внедрения.</p>
    </details>
  </section>

  <section>
    <div class="price-box">
      <div class="p-left">
        <h3>Внедрение AI SEO-агента (MCP-стек) для команды</h3>
        <p>Фикс-прайс и фикс-срок согласовываются после аудита вашего стека — цена зависит от количества систем и сценариев.</p>
      </div>
      <div class="p-right">
        <span class="price">$2000–2500</span>
        <span class="time">срок 7–10 дней</span>
        <a class="btn" href="<?php echo esc_url( YSA_TELEGRAM_URL ); ?>" target="_blank" rel="noopener">Обсудить</a>
      </div>
    </div>
  </section>

  <section>
    <div class="sec-head"><h2>Смотрите также</h2></div>
    <div class="related">
      <a href="<?php echo esc_url( ysa_service_url( 'betting-gaming' ) ); ?>">SEO для Betting/Gaming</a>
      <a href="<?php echo esc_url( ysa_service_url( 'tehnicheskiy-audit' ) ); ?>">Технический SEO-аудит + Roadmap</a>
      <a href="<?php echo esc_url( ysa_service_url( 'geo-aiseo' ) ); ?>">GEO/AISEO Readiness Audit</a>
    </div>
  </section>
</div>

<?php
get_footer();
